"""Local yfinance-compatible market data source.

This source is used both as a direct fallback and as the normalization reference
for SDU_DataScienceTool-based ingestion.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Iterable

import pandas as pd
import yfinance as yf


@dataclass(frozen=True)
class MarketDataRequest:
    """Simple request object for daily OHLCV market data."""

    tickers: list[str]
    start_date: str
    end_date: str


class YFinanceMarketSource:
    """Fetch daily OHLCV data using yfinance and return a normalized DataFrame."""

    source_name = "yfinance"

    async def fetch_prices(
        self,
        tickers: Iterable[str],
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        frames: list[pd.DataFrame] = []

        for ticker in tickers:
            normalized_ticker = ticker.strip().upper()
            if not normalized_ticker:
                continue

            frame = yf.download(
                normalized_ticker,
                start=start_date,
                end=end_date,
                interval="1d",
                auto_adjust=False,
                progress=False,
                group_by="column",
                threads=False,
            )

            if frame.empty:
                continue

            if isinstance(frame.columns, pd.MultiIndex):
                frame.columns = [
                    "_".join(str(part) for part in column if part)
                    for column in frame.columns
                ]

            frame = frame.reset_index()
            frame["ticker"] = normalized_ticker
            frames.append(frame)

        if not frames:
            return pd.DataFrame(
                columns=[
                    "ticker",
                    "price_date",
                    "open",
                    "high",
                    "low",
                    "close",
                    "adj_close",
                    "volume",
                ]
            )

        return normalize_price_frame(pd.concat(frames, ignore_index=True))


def normalize_price_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Normalize yfinance/SDU_DataScienceTool OHLCV output to one schema."""

    if frame.empty:
        return frame

    renamed = frame.copy()
    renamed.columns = [str(column).strip().lower().replace(" ", "_") for column in renamed.columns]

    # yfinance can return "date" or "datetime"; SDU_DataScienceTool may use "timestamp".
    date_column = next(
        (
            candidate
            for candidate in ["price_date", "date", "datetime", "timestamp"]
            if candidate in renamed.columns
        ),
        None,
    )

    if not date_column:
        raise ValueError(
            "Could not find a date column in market data frame. "
            f"Available columns: {list(renamed.columns)}"
        )

    # Common adjusted-close variants.
    if "adj_close" not in renamed.columns:
        for candidate in ["adj_close", "adjclose", "adjusted_close", "adj_close_"]:
            if candidate in renamed.columns:
                renamed["adj_close"] = renamed[candidate]
                break

    if "adj_close" not in renamed.columns:
        renamed["adj_close"] = renamed.get("close")

    if "ticker" not in renamed.columns and "tic" in renamed.columns:
        renamed["ticker"] = renamed["tic"]

    if "ticker" not in renamed.columns:
        raise ValueError("Could not find ticker column in market data frame.")

    required = ["open", "high", "low", "close", "volume"]
    missing = [column for column in required if column not in renamed.columns]
    if missing:
        raise ValueError(
            f"Missing required OHLCV columns: {missing}. "
            f"Available columns: {list(renamed.columns)}"
        )

    normalized = pd.DataFrame(
        {
            "ticker": renamed["ticker"].astype(str).str.upper(),
            "price_date": pd.to_datetime(renamed[date_column]).dt.date,
            "open": pd.to_numeric(renamed["open"], errors="coerce"),
            "high": pd.to_numeric(renamed["high"], errors="coerce"),
            "low": pd.to_numeric(renamed["low"], errors="coerce"),
            "close": pd.to_numeric(renamed["close"], errors="coerce"),
            "adj_close": pd.to_numeric(renamed["adj_close"], errors="coerce"),
            "volume": pd.to_numeric(renamed["volume"], errors="coerce").fillna(0).astype("int64"),
        }
    )

    normalized = normalized.dropna(subset=["open", "high", "low", "close"])
    normalized = normalized.drop_duplicates(subset=["ticker", "price_date"])
    normalized = normalized.sort_values(["ticker", "price_date"]).reset_index(drop=True)

    return normalized
