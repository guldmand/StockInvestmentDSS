# =============================================================================
# copilot-diagnostics/run_all.ps1
# =============================================================================
# Runs all four IQN HOLD-collapse ablation experiments sequentially in the
# recommended order (D, A, B, C) and then builds the cross-experiment report.
#
# Prerequisite:
#   conda activate stockdss
# =============================================================================

$ErrorActionPreference = "Continue"

$root = $PSScriptRoot
$results = Join-Path $root "results"
New-Item -ItemType Directory -Force -Path $results | Out-Null

$mainLog = Join-Path $results "run_all.log"
Start-Transcript -Path $mainLog -Append | Out-Null

Write-Host "=========================================================="
Write-Host " IQN HOLD-collapse diagnostic - run_all"
Write-Host " Started: $((Get-Date).ToString('o'))"
Write-Host "=========================================================="

# Recommended order: D (cheapest, isolates costs), A (isolates CVaR),
# then B and C which are more expensive.
$experiments = @(
    "run_experiment_d_zero_cost.ps1",
    "run_experiment_a_no_cvar.ps1",
    "run_experiment_b_more_training.ps1",
    "run_experiment_c_longer_window.ps1"
)

foreach ($e in $experiments) {
    $path = Join-Path (Join-Path $root "experiments") $e
    Write-Host ""
    Write-Host "----------------------------------------------------------"
    Write-Host " Running: $e"
    Write-Host "----------------------------------------------------------"
    try {
        & $path
    } catch {
        Write-Warning "Experiment $e failed: $_"
    }
}

Write-Host ""
Write-Host "=========================================================="
Write-Host " Building cross-experiment comparison report"
Write-Host "=========================================================="
try {
    & python (Join-Path $root "compare.py")
} catch {
    Write-Warning "compare.py failed: $_"
}

Write-Host ""
Write-Host "Done. Report: $(Join-Path $results 'comparison_report.md')"
Stop-Transcript | Out-Null
