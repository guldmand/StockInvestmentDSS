# IQN HOLD-Collapse — Diagnostisk Oversigt

> **Formål:** Forklare hvorfor 3 ud af 5 seeds i den seneste D-IQN-DSS multiseed-kørsel
> (`outputs/runs/2026_05_20_054007_d_iqn_dss_iqn_learning_curve_multiseed_summary`)
> kollapser til en ren HOLD-policy, og hvilke eksperimenter der kan isolere årsagen.
>
> Denne mappe (`copilot-diagnostics/`) er bevidst **selvstændig**. Den indeholder kun
> dokumentation og wrapper-scripts der sætter eksisterende runners op via
> environment-variabler. Ingen filer i `src/`, `configs/` eller andre projekt-mapper
> ændres. Hele mappen kan slettes uden spor.

---

## 1. Symptom

I q50-ablationen (score_mode = q50, dvs. ren median uden CVaR-penalty ved selektion):

| Seed | q50(HOLD) | q50(BUY) | HOLD − BUY | Trades | Decisions |
|------|-----------|----------|------------|--------|-----------|
| 1    | 16,669.44 | 14,682.70 |  +1,986.73 | 0 | 271 |
| 2    | 86,118.76 | 77,435.64 |  +8,683.11 | 0 | 271 |
| 5    | 94,702.17 | 83,276.59 | +11,425.57 | 0 | 271 |

- 0 trades, 0 maskerede actions.
- `best_allowed_non_hold_action_by_score` = BUY (dvs. BUY var tilladt og var bedste
  non-HOLD valg).
- Greedy selektion valgte alligevel HOLD i alle 271 eval-steps fordi HOLD havde
  højere q50-score.

Seeds 3 og 4 handlede aktivt i samme setup.

## 2. Hvad scores faktisk betyder

Scores er **ikke kroner og ikke procentafkast**. De er IQN's interne action-value
estimater på den lærte return-distribution:

- For hver state estimerer IQN en distribution `Z(s, a)` over fremtidig diskonteret
  reward.
- `q50(a)` er medianen af den distribution for handling `a`.
- I `q50`-ablationen er `score(a) = q50(a)`, og agenten vælger den tilladte action
  med højeste score.
- De rapporterede tal er gennemsnit af `score(a)` over de 271 eval-steps.

Absolutte tal afhænger af reward-skala, gamma, træningsforløb og netværksskala.
Det meningsfulde er **gappet inden for samme seed**, ikke værdien på tværs af seeds.

## 3. Hvorfor q50-ablation ikke "løste" problemet

`risk_lambda=0.75` påvirker selve **træningen**: target-distributionen og dermed
hvad netværket lærer at estimere som `Z(s, BUY)`. Hvis CVaR-penalty under træning
har skubbet BUY's distribution nedad, hjælper det ikke at ændre **selektionen** ved
eval bagefter — biasen er allerede internaliseret i netværket.

Eksperiment A nedenfor isolerer denne effekt ved at sætte `risk_lambda=0` under
selve træningen.

## 4. Hypoteser, prioriteret

| # | Hypotese | Hvorfor sandsynlig | Hvilket eksperiment isolerer det |
|---|----------|--------------------|----------------------------------|
| 1 | Transaktionsomkostning (`buy_cost_pct=0.001`) gør hver BUY garanteret negativ på step-niveau, mens HOLD = 0 omkostning. Med reward-scaling 1e-4 og portfolio-baseret reward bliver bias systematisk og self-reinforcing. | Asymmetri pr. step. Greedy IQN bootstrapper på den. | **D** |
| 2 | CVaR-penalty i træning skubber Z(s, BUY) ned i venstre hale → også q50 påvirkes. | `risk_lambda=0.75` er aggressiv; q50-eval løser ikke lært bias. | **A** |
| 3 | Replay-buffer domineres af HOLD/cash-only states efter tidlige dårlige BUYs. BUY-Q underestimeres pga. få positive transitioner. | Forklarer seed-bistabilitet (2/5 finder ud af det, 3/5 gør ikke). | **B**, **C** |
| 4 | Epsilon-decay (25k steps) lukker eksploration før BUY-Q er konvergeret ved 25k total steps (=samme størrelse). | `epsilon_final=0.05` er lavt; korrektionsvindue meget kort. | **B** |
| 5 | Aggregeret BUY-action (én "BUY" allokerer på tværs af tickers) giver høj reward-varians per step → konservativ q50. | Bevidst designvalg, beholdes for nu. | Ingen — kvalitativ note |
| 6 | Træningsperioden 2018–2022 indeholder regimer (COVID-2020, 2022-bear) der straffer BUY tidligt og dominerer replay. | Forklarer seed-bistabilitet og at HOLD virker "sikker". | **C** |

## 5. Eksperimenter (alle wrapper-scripts i `experiments/`)

Alle eksperimenter:

- bruger samme demo_5 long-PIT-setup som baseline (`run_mode_b_repro_demo5_iqn.ps1`),
- kører **seeds 1, 2, 3, 4, 5**,
- kalder eksisterende runner `run_iqn_learning_curve_multiseed_launcher` uændret,
- kører efterfølgende `run_iqn_reward_action_diagnostic` mod den nye summary,
- kopierer kun aggregerede CSV/JSON/MD-artefakter til
  `copilot-diagnostics/results/experiment_<x>/` for selvstændig analyse.

| Eksperiment | Variabel ændret ift. baseline | Forventet effekt hvis hypotesen passer |
|-------------|--------------------------------|----------------------------------------|
| **A — no_cvar**       | `STOCK_INVESTMENT_DSS_IQN_BACKTEST_RISK_LAMBDA=0.0` | HOLD−BUY gap krymper kraftigt eller forsvinder |
| **B — more_training** | `IQN_LEARNING_CURVE_TOTAL_STEPS=50000`, `IQN_EPSILON_DECAY_STEPS=40000` | Flere seeds finder BUY, gap mindskes |
| **C — longer_window** | `DAILY_DATA_START=2015-01-01`, `PIT_POINT_IN_TIME=2022-01-01` | Mere regime-variation, BUY-Q bedre estimeret |
| **D — zero_cost**     | `FINRL_ENV_BUY_COST_PCT=0.0`, `FINRL_ENV_SELL_COST_PCT=0.0` | Hvis collapse forsvinder → omkostning er primær årsag |

**Anbefalet kørsels-rækkefølge ved knap tid:** D → A → B → C. D og A er billigst og
isolerer de to mest sandsynlige rødder.

## 6. Sådan eksekveres

Fra projekt-rod, med conda-miljø aktiveret:

```powershell
conda activate stockdss
.\copilot-diagnostics\run_all.ps1
```

Eller individuelt:

```powershell
conda activate stockdss
.\copilot-diagnostics\experiments\run_experiment_d_zero_cost.ps1
.\copilot-diagnostics\experiments\run_experiment_a_no_cvar.ps1
# osv.
```

Efter alle er kørt:

```powershell
python copilot-diagnostics\compare.py
```

Resultat: `copilot-diagnostics\results\comparison_report.md` med cross-experiment
tabel pr. seed × eksperiment for `hold_share`, `hold_score_minus_buy_score`,
`buy_reward_mean`, `cash_only_share` og `epsilon_final`.

## 7. Hvad rapporten vil afgøre

- **Hvis D fjerner collapse** → reward-design er primær årsag. Næste skridt:
  log-returns reward, cost annealing, eller separat trade-bonus.
- **Hvis A fjerner collapse** → risk-træning er primær årsag. Næste skridt:
  risk-lambda warmup, eller anneal under træning.
- **Hvis B fjerner collapse** → konvergens/eksploration. Næste skridt: standard
  træningsbudget op, langsommere epsilon, evt. NoisyNet.
- **Hvis C fjerner collapse** → data-distribution. Næste skridt: bredere
  train-window som standard, eller curriculum.
- **Hvis ingen fjerner collapse** → strukturelt problem (aggregeret action, state-
  repræsentation, eller netværks-arkitektur). Næste skridt: rethink action-space.

## 8. Eksplicit scope

**Inkluderet:**
- Diagnose-dokument og fire ablation-eksperimenter.
- Wrapper-scripts der kun sætter env-vars.
- Cross-experiment sammenligning.

**Ekskluderet:**
- Ændringer i `src/`, `configs/` eller andre projekt-mapper.
- Action-space ændringer (aggregeret BUY beholdes).
- Auto-tuning / hyperparameter-søgning.
- Ændringer i reward-funktionens form (kun cost = 0 ablation).

## 9. Bemærkning om output-placering

De underliggende træningskørsler (kaldt af multiseed-launcheren) skriver stadig
til `outputs/runs/` — det er den eksisterende runners adfærd og kan ikke ændres
uden at modificere `src/`. Til gengæld kopierer hvert eksperiment-script de
relevante aggregerede artefakter til `copilot-diagnostics/results/experiment_<x>/`,
så analysen er selvstændig og kan inspiceres/slettes uafhængigt.

For at rydde op:

```powershell
# Sletter kun diagnostik-mappen (træningsrunsne i outputs/runs/ bevares)
Remove-Item -Recurse -Force copilot-diagnostics
```
