"""
Phase B.5 — 4-Way Ablation Suite

Compares four ablation configurations against the edl_a_cf_label ground truth
on the same 120-row test set as Phase B.4:

  A1  IQN-only:        final_action = normalize(iqn_chosen_action)
  A2  IQN + HDP:       final_action = normalize(hierarchical_action_type)
  A3  IQN + EDL:       IQN action filtered by EDL gate (HDP bypassed)
  A4  IQN + HDP + EDL: Full pipeline (replicates Phase B.4 Phase D)

For A3 and A4, percentile thresholds are computed from the train* vacuity
distribution (same as Phase B.4.D): p33 / p66 / max(p66, 0.50).

INPUTS:
  - Phase B.2 combined CSV:
      outputs/runs/<latest_b2_run>/audit/combined_with_counterfactual_labels.csv
  - Phase B.3 MERGED ensemble:
      outputs/runs/MERGED_..._COMPLETE/models/edl_action_classifier_v3_fold_{0..9}.pt

OUTPUTS:
  outputs/runs/<timestamp>_d_iqn_dss_phase_b5_ablation_suite/
    audit/
      ablation_a1_iqn_only.csv
      ablation_a2_iqn_hdp.csv
      ablation_a3_iqn_edl.csv
      ablation_a4_iqn_hdp_edl.csv
      ablation_comparison.csv          (4-row cross-ablation summary)
    config/
      phase_b5_config.json
    data/
      test_set_predictions.csv
    logs/
      run.log
    metrics/
      per_ablation_metrics.json
      confusion_matrices.json
      cross_ablation_summary.json
    plots/
      ablation_accuracy_comparison.png
      ablation_confusion_matrices.png
      ablation_per_class_metrics.png   (full mode only)
      ablation_action_distribution.png (full mode only)
    summary/
      phase_b5_summary.md
      phase_b5_summary.json

USAGE:
  cd <repo_root>
  export PYTHONPATH=src
  python -m stock_investment_dss.runner.run_phase_b5_ablation_suite

  # Optional flags:
  #   --quick                  Skip per-class + action distribution plots (~2 min)
  #   --no-wandb               Disable W&B logging
  #   --combined-csv PATH      Override Phase B.2 combined CSV (required for B.6)
  #   --merged-folder PATH     Override Phase B.3 MERGED folder (required for B.6)
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.metrics import (
    classification_report,
    confusion_matrix as sk_confusion_matrix,
)

from stock_investment_dss.uncertainty.edl_gate import (
    EDLGate,
    EDLGateConfig,
    GATE_RECOMMEND_AS_IS,
    GATE_REDUCE_SIZE,
    GATE_FORCE_HOLD,
    GATE_HUMAN_REVIEW,
    GATE_STRATEGY_REVIEW,
    ALL_GATE_OUTPUTS,
)

# ============================================================================
# Constants
# ============================================================================
ACTION_NAMES_3CLASS = ["BUY", "SELL", "HOLD"]
ACTION_TO_IDX = {"BUY": 0, "SELL": 1, "HOLD": 2}
IDX_TO_ACTION = {0: "BUY", 1: "SELL", 2: "HOLD"}

# Feature exclusion sets (56 features — matches Phase B.3 v3 training exactly)
_EXCLUDE_PREFIXES = ("edl_a_", "edl_b_", "edl_c_", "edl_label_")
_EXCLUDE_EXACT = {
    "decision_id",
    "date",
    "visible_data_cutoff",
    "eval_step",
    "source_iqn_run_id",
    "dataset_id",
    "pit_split_id",
    "selected_iqn_action",
    "iqn_chosen_action",
    "hierarchical_action_type",
    "selected_ticker",
    "selected_size",
    "final_recommendation_before_edl",
    "final_recommendation_source",
    "selected_action_type",
}

# Ablation display labels and plot colors
ABLATION_LABELS = {
    "A1": "A1: IQN-only",
    "A2": "A2: IQN+HDP",
    "A3": "A3: IQN+EDL",
    "A4": "A4: IQN+HDP+EDL",
}
ABLATION_COLORS = {
    "A1": "steelblue",
    "A2": "darkorange",
    "A3": "mediumseagreen",
    "A4": "crimson",
}


# ============================================================================
# Model architecture — copied verbatim from Phase B.4 production runner
# (must match Phase B.3 v3 training architecture exactly)
# ============================================================================
class EDLActionNetworkV3(nn.Module):
    """Exact replica of EDL-A architecture used in Phase B.3 v3 training.

    Matches run_edl_action_training_v3_production.py exactly:
      - attribute 'body' (not 'net')
      - LayerNorm after each Linear hidden layer
      - F.relu evidence head returning alpha = evidence + 1.0
    """

    _ACTIVATION_MAP = {
        "ReLU": nn.ReLU,
        "GELU": nn.GELU,
        "SiLU": nn.SiLU,
        "Mish": nn.Mish,
    }

    def __init__(
        self,
        input_dim: int,
        num_classes: int,
        hidden_dims: list,
        activation: str = "SiLU",
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        if activation not in self._ACTIVATION_MAP:
            raise ValueError(f"Unknown activation '{activation}'")
        ActFn = self._ACTIVATION_MAP[activation]

        layers = []
        prev_dim = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(prev_dim, h))
            layers.append(nn.LayerNorm(h))
            layers.append(ActFn())
            if dropout > 0.0:
                layers.append(nn.Dropout(dropout))
            prev_dim = h
        layers.append(nn.Linear(prev_dim, num_classes))
        self.body = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        logits = self.body(x)
        evidence = F.relu(logits)
        return evidence + 1.0


# ============================================================================
# W&B helpers — copied verbatim from Phase B.4 production runner
# ============================================================================
def load_wandb_env(env_file: Path = Path(".env.wandb.local")) -> dict:
    """Load W&B credentials from .env.wandb.local"""
    cfg = {
        "enabled": False,
        "project": "StockInvestmentDSS",
        "entity": "guldmand-SDU",
        "api_key": None,
    }
    if not env_file.exists():
        return cfg
    with open(env_file) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            os.environ[key] = value
            if key == "STOCK_INVESTMENT_DSS_WANDB_ENABLED":
                cfg["enabled"] = value.lower() == "true"
            elif key == "STOCK_INVESTMENT_DSS_WANDB_PROJECT":
                cfg["project"] = value
            elif key == "STOCK_INVESTMENT_DSS_WANDB_ENTITY":
                cfg["entity"] = value
            elif key == "WANDB_API_KEY":
                cfg["api_key"] = value
    return cfg


# ============================================================================
# Auto-discovery helpers — copied verbatim from Phase B.4 production runner
# ============================================================================
def find_latest_phase_b2_run(runs_dir: Path) -> Optional[Path]:
    """Find latest Phase B.2 (counterfactual oracle) run with combined CSV."""
    candidates = sorted(
        runs_dir.glob("*_d_iqn_dss_edl_counterfactual_oracle_production")
    )
    for run_dir in reversed(candidates):
        csv_path = run_dir / "audit" / "combined_with_counterfactual_labels.csv"
        if csv_path.exists() and csv_path.stat().st_size > 1000:
            return run_dir
    return None


def find_merged_folder(runs_dir: Path) -> Optional[Path]:
    """Find the MERGED training folder."""
    candidates = sorted(runs_dir.glob("MERGED_*_edl_action_training_v3_COMPLETE"))
    if candidates:
        return candidates[-1]
    return None


# ============================================================================
# Feature engineering — copied verbatim from Phase B.4 production runner
# ============================================================================
def infer_feature_columns(df: pd.DataFrame) -> list:
    """Determine which columns to use as features (matches Phase B.3 v3 training)."""
    features = []
    for col in df.columns:
        if col in _EXCLUDE_EXACT:
            continue
        if any(col.startswith(p) for p in _EXCLUDE_PREFIXES):
            continue
        if df[col].dtype == "object":
            continue
        features.append(col)
    return features


def standardize_features(
    X: np.ndarray, mean: np.ndarray, std: np.ndarray
) -> np.ndarray:
    """Standardize features using train* mean/std (no test leakage)."""
    std_safe = np.where(std < 1e-8, 1.0, std)
    return (X - mean) / std_safe


def normalize_action(action_raw) -> str:
    """Map various action strings to canonical BUY / SELL / HOLD."""
    if not isinstance(action_raw, str):
        return "HOLD"
    a = action_raw.upper().strip()
    if a.startswith("BUY"):
        return "BUY"
    if a.startswith("SELL"):
        return "SELL"
    return "HOLD"


# ============================================================================
# Ensemble inference — copied verbatim from Phase B.4 production runner
# ============================================================================
def load_ensemble_models(
    merged_folder: Path,
    input_dim: int,
    hidden_dims: list,
    num_classes: int = 3,
    dropout: float = 0.0,
    activation: str = "ReLU",
    device: torch.device = torch.device("cpu"),
) -> list:
    """Load 10-fold models from MERGED folder."""
    models = []
    for fold_idx in range(10):
        model_path = (
            merged_folder / "models" / f"edl_action_classifier_v3_fold_{fold_idx}.pt"
        )
        if not model_path.exists():
            raise FileNotFoundError(f"Missing fold model: {model_path}")
        model = EDLActionNetworkV3(
            input_dim, num_classes, hidden_dims, activation, dropout
        )
        state = torch.load(model_path, map_location=device)
        if isinstance(state, dict) and "state_dict" in state:
            model.load_state_dict(state["state_dict"])
        else:
            model.load_state_dict(state)
        model.eval()
        model.to(device)
        models.append(model)
    return models


def ensemble_predict(models: list, X: np.ndarray, device: torch.device) -> dict:
    """
    Run ensemble inference. Returns dict with:
      ensemble_alpha:  (N, K) average Dirichlet alpha
      ensemble_probs:  (N, K) probabilities
      ensemble_pred:   (N,)  argmax predictions
      vacuity:         (N,)  epistemic uncertainty K/S
      disagreement:    (N,)  fraction of folds disagreeing with ensemble
    """
    X_t = torch.tensor(X, dtype=torch.float32, device=device)
    K = 3

    per_fold_evidence = []
    per_fold_preds = []
    with torch.no_grad():
        for model in models:
            evidence = model(X_t).cpu().numpy()
            alpha = evidence + 1.0
            per_fold_evidence.append(alpha)
            per_fold_preds.append(np.argmax(alpha, axis=1))

    ensemble_alpha = np.mean(np.stack(per_fold_evidence, axis=0), axis=0)
    S = ensemble_alpha.sum(axis=1, keepdims=True)
    ensemble_probs = ensemble_alpha / S
    ensemble_pred = np.argmax(ensemble_alpha, axis=1)
    vacuity = K / S.flatten()

    per_fold_preds_arr = np.stack(per_fold_preds, axis=0)
    disagreement = np.mean(per_fold_preds_arr != ensemble_pred[np.newaxis, :], axis=0)

    return {
        "ensemble_alpha": ensemble_alpha,
        "ensemble_probs": ensemble_probs,
        "ensemble_pred": ensemble_pred,
        "vacuity": vacuity,
        "disagreement": disagreement,
    }


# ============================================================================
# Gate application — copied verbatim from Phase B.4 production runner
# ============================================================================
def apply_gate_to_dataset(
    df: pd.DataFrame,
    edl_results: dict,
    gate_config: EDLGateConfig,
    risk_modulation: Optional[dict] = None,
) -> pd.DataFrame:
    """
    Apply EDLGate to all rows in df.

    For Phase B.5:
      - A3: df must have hierarchical_action_type overridden with iqn_chosen_action
      - A4: df uses hierarchical_action_type unchanged
    """
    vacuity = edl_results["vacuity"]
    pred_idx = edl_results["ensemble_pred"]
    disagreement = edl_results["disagreement"]

    results = []
    for idx in range(len(df)):
        row = df.iloc[idx]
        hdp_action = normalize_action(row.get("hierarchical_action_type", "HOLD"))
        selected_size = row.get("selected_size", "")
        if pd.isna(selected_size):
            selected_size = ""
        original_fraction = float(row.get("selected_size_fraction", 0.0) or 0.0)

        edl_pred_action = IDX_TO_ACTION[int(pred_idx[idx])]
        edl_agrees = edl_pred_action == hdp_action

        if risk_modulation is not None:
            row_risk = float(row.get("risk_score", 0.5) or 0.5)
            scale = risk_modulation["scale_factor"]
            risk_factor = 0.5 + 0.5 * row_risk
            eff_cfg = EDLGateConfig(
                recommend_as_is_max_vacuity=gate_config.recommend_as_is_max_vacuity
                * scale
                * risk_factor,
                reduce_size_max_vacuity=gate_config.reduce_size_max_vacuity
                * scale
                * risk_factor,
                force_hold_min_vacuity=gate_config.force_hold_min_vacuity
                * scale
                * risk_factor,
                rebalance_signal_threshold=gate_config.rebalance_signal_threshold,
                change_strategy_signal_threshold=gate_config.change_strategy_signal_threshold,
                disagreement_review_threshold=gate_config.disagreement_review_threshold,
                uncertainty_lambda=gate_config.uncertainty_lambda,
            )
        else:
            eff_cfg = gate_config

        gate = EDLGate(eff_cfg)
        result = gate.apply(
            selected_action=hdp_action,
            selected_size=str(selected_size),
            original_fraction=original_fraction,
            vacuity=float(vacuity[idx]),
            edl_agrees=edl_agrees,
            edl_predicted_action=edl_pred_action,
            p_rebalance=0.0,
            p_change_strategy=0.0,
            disagreement_score=float(disagreement[idx]),
            uncertainty_penalty=eff_cfg.uncertainty_lambda * float(vacuity[idx]),
        )

        out = result.to_audit_dict()
        out["row_idx"] = idx
        out["decision_id"] = row.get("decision_id", "")
        out["date"] = row.get("date", "")
        out["hdp_action"] = hdp_action
        out["edl_pred_action"] = edl_pred_action
        out["edl_agrees"] = edl_agrees
        out["vacuity"] = float(vacuity[idx])
        out["disagreement"] = float(disagreement[idx])
        out["risk_score"] = float(row.get("risk_score", 0.5) or 0.5)
        out["cf_label"] = row.get("edl_a_cf_label", "")
        out["thr_rec_as_is"] = eff_cfg.recommend_as_is_max_vacuity
        out["thr_reduce_size"] = eff_cfg.reduce_size_max_vacuity
        out["thr_force_hold"] = eff_cfg.force_hold_min_vacuity
        results.append(out)

    return pd.DataFrame(results)


def compute_percentile_thresholds(vacuity: np.ndarray) -> EDLGateConfig:
    """Compute data-driven thresholds from train* vacuity percentiles.

    recommend_as_is_max_vacuity = p33
    reduce_size_max_vacuity     = p66
    force_hold_min_vacuity      = max(p66, 0.50)
    """
    p33 = float(np.percentile(vacuity, 33))
    p66 = float(np.percentile(vacuity, 66))
    return EDLGateConfig(
        recommend_as_is_max_vacuity=p33,
        reduce_size_max_vacuity=p66,
        force_hold_min_vacuity=max(p66, 0.50),
    )


# ============================================================================
# B.5-specific: Ablation metrics
# ============================================================================
def compute_ablation_metrics(
    final_actions: pd.Series,
    cf_labels: pd.Series,
    source_actions: Optional[pd.Series] = None,
) -> dict:
    """Compute classification metrics for one ablation configuration.

    Args:
        final_actions:  Predicted actions (BUY/SELL/HOLD strings).
        cf_labels:      Ground truth counterfactual labels.
        source_actions: Pre-gate/pre-pipeline actions for n_modified count.
                        A2: pass iqn_chosen_action (n_modified vs A1).
                        A3: pass iqn_chosen_action (n_modified vs A1).
                        A4: pass hierarchical_action_type (n_modified vs A2).

    Returns dict with: overall_acc, n, macro_f1, per_class, confusion_matrix,
                       action_distribution, n_modified.
    """
    y_pred = final_actions.apply(normalize_action).reset_index(drop=True)
    y_true = cf_labels.apply(normalize_action).reset_index(drop=True)

    overall_acc = float((y_pred == y_true).mean())

    report = classification_report(
        y_true,
        y_pred,
        labels=ACTION_NAMES_3CLASS,
        output_dict=True,
        zero_division=0,
    )
    macro_f1 = float(report["macro avg"]["f1-score"])

    cm = sk_confusion_matrix(y_true, y_pred, labels=ACTION_NAMES_3CLASS)

    action_dist = {
        action: int((y_pred == action).sum()) for action in ACTION_NAMES_3CLASS
    }

    n_modified = 0
    if source_actions is not None:
        src_norm = source_actions.apply(normalize_action).reset_index(drop=True)
        n_modified = int((y_pred != src_norm).sum())

    return {
        "overall_acc": overall_acc,
        "n": len(y_pred),
        "macro_f1": macro_f1,
        "per_class": report,
        "confusion_matrix": cm.tolist(),
        "action_distribution": action_dist,
        "n_modified": n_modified,
    }


# ============================================================================
# B.5-specific: Ablation builders
# ============================================================================
def build_ablation_a1(df_test: pd.DataFrame) -> pd.DataFrame:
    """A1: IQN-only — use raw iqn_chosen_action as final action."""
    out = pd.DataFrame()
    out["row_idx"] = range(len(df_test))
    out["decision_id"] = df_test["decision_id"].values
    out["date"] = df_test["date"].values
    out["iqn_chosen_action"] = df_test["iqn_chosen_action"].fillna("HOLD").values
    out["final_action"] = out["iqn_chosen_action"].apply(normalize_action)
    out["cf_label"] = df_test["edl_a_cf_label"].fillna("HOLD").values
    out["ablation"] = "A1_iqn_only"
    out["is_correct"] = out["final_action"] == out["cf_label"].apply(normalize_action)
    return out.reset_index(drop=True)


def build_ablation_a2(df_test: pd.DataFrame) -> pd.DataFrame:
    """A2: IQN + HDP — use hierarchical_action_type as final action."""
    out = pd.DataFrame()
    out["row_idx"] = range(len(df_test))
    out["decision_id"] = df_test["decision_id"].values
    out["date"] = df_test["date"].values
    out["iqn_chosen_action"] = df_test["iqn_chosen_action"].fillna("HOLD").values
    out["hdp_action"] = df_test["hierarchical_action_type"].fillna("HOLD").values
    out["source_action"] = out["iqn_chosen_action"].apply(normalize_action)
    out["final_action"] = out["hdp_action"].apply(normalize_action)
    out["cf_label"] = df_test["edl_a_cf_label"].fillna("HOLD").values
    out["ablation"] = "A2_iqn_hdp"
    out["is_correct"] = out["final_action"] == out["cf_label"].apply(normalize_action)
    return out.reset_index(drop=True)


def build_ablation_a3(
    df_test: pd.DataFrame,
    edl_test: dict,
    percentile_cfg: EDLGateConfig,
) -> pd.DataFrame:
    """A3: IQN + EDL (no HDP) — IQN action gated by EDL, bypassing HDP.

    Trick: override hierarchical_action_type with iqn_chosen_action so that
    apply_gate_to_dataset reads the IQN action as the gate input.
    """
    df_iqn_as_hdp = df_test.copy()
    df_iqn_as_hdp["hierarchical_action_type"] = df_test["iqn_chosen_action"].fillna(
        "HOLD"
    )
    df_gate = apply_gate_to_dataset(df_iqn_as_hdp, edl_test, percentile_cfg)
    df_gate["source_action"] = (
        df_test["iqn_chosen_action"].fillna("HOLD").apply(normalize_action).values
    )
    df_gate["ablation"] = "A3_iqn_edl"
    df_gate["is_correct"] = df_gate["final_action_after_edl_gate"].apply(
        normalize_action
    ) == df_gate["cf_label"].apply(normalize_action)
    return df_gate.reset_index(drop=True)


def build_ablation_a4(
    df_test: pd.DataFrame,
    edl_test: dict,
    percentile_cfg: EDLGateConfig,
) -> pd.DataFrame:
    """A4: IQN + HDP + EDL — full pipeline (replicates Phase B.4 Phase D)."""
    df_gate = apply_gate_to_dataset(df_test, edl_test, percentile_cfg)
    df_gate["source_action"] = (
        df_test["hierarchical_action_type"]
        .fillna("HOLD")
        .apply(normalize_action)
        .values
    )
    df_gate["ablation"] = "A4_iqn_hdp_edl"
    df_gate["is_correct"] = df_gate["final_action_after_edl_gate"].apply(
        normalize_action
    ) == df_gate["cf_label"].apply(normalize_action)
    return df_gate.reset_index(drop=True)


# ============================================================================
# B.5-specific: Plots
# ============================================================================
def plot_ablation_accuracy_comparison(
    metrics_per_ablation: dict,
    output_path: Path,
) -> None:
    """Grouped bar chart: overall accuracy and macro F1 per ablation."""
    ablation_keys = ["A1", "A2", "A3", "A4"]
    labels = [ABLATION_LABELS[k] for k in ablation_keys]
    accs = [metrics_per_ablation[k]["overall_acc"] for k in ablation_keys]
    f1s = [metrics_per_ablation[k]["macro_f1"] for k in ablation_keys]

    x = np.arange(len(ablation_keys))
    width = 0.35

    fig, ax = plt.subplots(figsize=(10, 6))
    bars_acc = ax.bar(
        x - width / 2,
        accs,
        width,
        label="Overall Accuracy",
        color=[ABLATION_COLORS[k] for k in ablation_keys],
        alpha=0.85,
        edgecolor="black",
    )
    bars_f1 = ax.bar(
        x + width / 2,
        f1s,
        width,
        label="Macro F1",
        color=[ABLATION_COLORS[k] for k in ablation_keys],
        alpha=0.50,
        edgecolor="black",
        hatch="//",
    )

    # Reference lines
    ax.axhline(1 / 3, color="gray", linestyle=":", linewidth=1, label="Random (1/3)")

    # Value annotations
    for bar in bars_acc:
        h = bar.get_height()
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            h + 0.005,
            f"{h:.3f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )
    for bar in bars_f1:
        h = bar.get_height()
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            h + 0.005,
            f"{h:.3f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=10)
    ax.set_ylabel("Score")
    ax.set_ylim(0, 1.05)
    ax.set_title("Phase B.5: Ablation Accuracy and Macro F1 Comparison")
    ax.legend(loc="upper left", fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    fig.savefig(output_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


def plot_ablation_confusion_matrices(
    metrics_per_ablation: dict,
    output_path: Path,
) -> None:
    """2x2 panel of row-normalised confusion matrices for all four ablations."""
    ablation_keys = ["A1", "A2", "A3", "A4"]
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes_flat = axes.flatten()

    for ax, key in zip(axes_flat, ablation_keys):
        cm = np.array(metrics_per_ablation[key]["confusion_matrix"], dtype=float)
        row_sums = cm.sum(axis=1, keepdims=True)
        row_sums = np.where(row_sums == 0, 1, row_sums)
        cm_norm = cm / row_sums

        im = ax.imshow(cm_norm, cmap="Blues", vmin=0, vmax=1, aspect="auto")
        ax.set_xticks(range(3))
        ax.set_yticks(range(3))
        ax.set_xticklabels(ACTION_NAMES_3CLASS)
        ax.set_yticklabels(ACTION_NAMES_3CLASS)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True (cf_label)")
        acc = metrics_per_ablation[key]["overall_acc"]
        ax.set_title(f"{ABLATION_LABELS[key]}  (acc={acc:.3f})")

        for i in range(3):
            for j in range(3):
                v = cm_norm[i, j]
                n = int(cm[i, j])
                color = "white" if v > 0.5 else "black"
                ax.text(
                    j,
                    i,
                    f"{v:.2f}\n(n={n})",
                    ha="center",
                    va="center",
                    fontsize=9,
                    color=color,
                )

        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    fig.suptitle(
        "Phase B.5: Row-Normalised Confusion Matrices per Ablation", fontsize=13
    )
    plt.tight_layout()
    fig.savefig(output_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


def plot_ablation_per_class_metrics(
    metrics_per_ablation: dict,
    output_path: Path,
) -> None:
    """3-panel figure: per-class precision/recall/F1 across all four ablations."""
    ablation_keys = ["A1", "A2", "A3", "A4"]
    classes = ACTION_NAMES_3CLASS
    metric_names = ["precision", "recall", "f1-score"]
    metric_labels = ["Precision", "Recall", "F1"]
    metric_colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]

    fig, axes = plt.subplots(1, 3, figsize=(16, 5), sharey=True)

    for ax, cls in zip(axes, classes):
        x = np.arange(len(ablation_keys))
        width = 0.25
        for m_idx, (metric_key, metric_label, color) in enumerate(
            zip(metric_names, metric_labels, metric_colors)
        ):
            values = []
            for abl_key in ablation_keys:
                cls_report = metrics_per_ablation[abl_key]["per_class"]
                values.append(float(cls_report.get(cls, {}).get(metric_key, 0.0)))

            offset = (m_idx - 1) * width
            bars = ax.bar(
                x + offset,
                values,
                width,
                label=metric_label if ax == axes[0] else "_nolegend_",
                color=color,
                alpha=0.82,
                edgecolor="black",
            )

        ax.set_xticks(x)
        ax.set_xticklabels(
            [ABLATION_LABELS[k] for k in ablation_keys], rotation=12, fontsize=8
        )
        ax.set_title(f"Class: {cls}")
        ax.set_ylim(0, 1.05)
        ax.grid(axis="y", alpha=0.3)

    axes[0].set_ylabel("Score")
    axes[0].legend(loc="upper left", fontsize=9)
    fig.suptitle(
        "Phase B.5: Per-Class Precision / Recall / F1 per Ablation", fontsize=13
    )
    plt.tight_layout()
    fig.savefig(output_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


def plot_ablation_action_distribution(
    metrics_per_ablation: dict,
    cf_labels: pd.Series,
    output_path: Path,
) -> None:
    """Stacked horizontal bar chart: action distribution for A1–A4 + ground truth."""
    ablation_keys = ["A1", "A2", "A3", "A4"]
    row_labels = [ABLATION_LABELS[k] for k in ablation_keys] + ["Ground Truth"]

    n_total = metrics_per_ablation["A1"]["n"]
    truth_dist = cf_labels.apply(normalize_action).value_counts()
    truth_row = {a: int(truth_dist.get(a, 0)) for a in ACTION_NAMES_3CLASS}

    rows = []
    for key in ablation_keys:
        rows.append(metrics_per_ablation[key]["action_distribution"])
    rows.append(truth_row)

    fractions = {a: [] for a in ACTION_NAMES_3CLASS}
    for row in rows:
        total = sum(row.values()) or 1
        for a in ACTION_NAMES_3CLASS:
            fractions[a].append(row.get(a, 0) / total)

    colors = {"BUY": "#2ca02c", "SELL": "#d62728", "HOLD": "#7f7f7f"}

    fig, ax = plt.subplots(figsize=(10, 6))
    y = np.arange(len(row_labels))
    left = np.zeros(len(row_labels))

    for action in ACTION_NAMES_3CLASS:
        vals = np.array(fractions[action])
        ax.barh(
            y,
            vals,
            left=left,
            label=action,
            color=colors[action],
            alpha=0.82,
            edgecolor="black",
            linewidth=0.5,
        )
        for i, (v, l) in enumerate(zip(vals, left)):
            if v > 0.04:
                ax.text(
                    l + v / 2,
                    i,
                    f"{v:.1%}",
                    ha="center",
                    va="center",
                    fontsize=8,
                    color="white",
                    fontweight="bold",
                )
        left += vals

    ax.set_yticks(y)
    ax.set_yticklabels(row_labels, fontsize=9)
    ax.set_xlabel("Fraction of decisions")
    ax.set_xlim(0, 1)
    ax.set_title("Phase B.5: Action Distribution per Ablation vs Ground Truth")
    ax.legend(loc="lower right", fontsize=9)
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    fig.savefig(output_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


# ============================================================================
# Main
# ============================================================================
def main() -> int:
    parser = argparse.ArgumentParser(description="Phase B.5 — 4-Way Ablation Suite")
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Skip per-class and action-distribution plots (~2 min faster)",
    )
    parser.add_argument("--no-wandb", action="store_true", help="Disable W&B logging")
    parser.add_argument(
        "--combined-csv",
        type=str,
        default=None,
        help="Override Phase B.2 combined CSV path (required for Phase B.6)",
    )
    parser.add_argument(
        "--merged-folder",
        type=str,
        default=None,
        help="Override Phase B.3 MERGED folder path (required for Phase B.6)",
    )
    args = parser.parse_args()

    # ------------------------------------------------------------------
    # Setup: run directory + logging
    # ------------------------------------------------------------------
    repo_root = Path.cwd()
    runs_dir = repo_root / "outputs" / "runs"

    timestamp = datetime.now().strftime("%Y_%m_%d_%H%M%S")
    run_name = f"{timestamp}_d_iqn_dss_phase_b5_ablation_suite"
    run_dir = runs_dir / run_name
    for sub in ["audit", "config", "data", "logs", "metrics", "plots", "summary"]:
        (run_dir / sub).mkdir(parents=True, exist_ok=True)

    log_file = run_dir / "logs" / "run.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )
    logger = logging.getLogger(f"stock_investment_dss.run.{run_name}")

    logger.info("=" * 80)
    logger.info("=== Phase B.5 — 4-Way Ablation Suite ===")
    logger.info("=" * 80)
    logger.info(f"Run dir:    {run_dir}")
    logger.info(f"Quick mode: {args.quick}")

    # ------------------------------------------------------------------
    # Find / validate inputs
    # ------------------------------------------------------------------
    if args.combined_csv:
        combined_csv = Path(args.combined_csv)
    else:
        b2_run = find_latest_phase_b2_run(runs_dir)
        if b2_run is None:
            logger.error("Could not find Phase B.2 run with combined CSV.")
            return 1
        combined_csv = b2_run / "audit" / "combined_with_counterfactual_labels.csv"

    if not combined_csv.exists():
        logger.error(f"Combined CSV not found: {combined_csv}")
        return 1
    logger.info(f"Combined CSV (B.2): {combined_csv}")

    if args.merged_folder:
        merged_folder = Path(args.merged_folder)
    else:
        merged_folder = find_merged_folder(runs_dir)
        if merged_folder is None:
            logger.error("Could not find Phase B.3 MERGED folder.")
            return 1
    logger.info(f"MERGED folder (B.3): {merged_folder}")

    # ------------------------------------------------------------------
    # Load data
    # ------------------------------------------------------------------
    df_all = pd.read_csv(combined_csv)
    logger.info(f"Loaded combined CSV: {len(df_all)} rows, {len(df_all.columns)} cols")

    if "edl_a_cf_label_available" in df_all.columns:
        n_before = len(df_all)
        df_all = df_all[df_all["edl_a_cf_label_available"]].reset_index(drop=True)
        logger.info(
            f"Dropped {n_before - len(df_all)} rows with unavailable cf labels "
            f"({len(df_all)} remaining)"
        )

    # ------------------------------------------------------------------
    # Reproduce exact Phase B.3 / B.4 train / test split
    # ------------------------------------------------------------------
    from sklearn.model_selection import train_test_split as sk_train_test_split

    training_config_path = merged_folder / "config" / "training_config.json"
    with open(training_config_path) as f:
        training_cfg = json.load(f)
    split_seed = training_cfg["seed"]
    test_split_ratio = training_cfg["test_split"]
    logger.info(f"Training config: seed={split_seed}, test_split={test_split_ratio}")

    _class_to_id = {cls: idx for idx, cls in enumerate(training_cfg["action_classes"])}
    y_all = df_all["edl_a_cf_label"].map(_class_to_id).fillna(0).values.astype(int)
    all_indices = np.arange(len(df_all))
    train_idx, test_idx = sk_train_test_split(
        all_indices,
        test_size=test_split_ratio,
        stratify=y_all,
        random_state=split_seed,
    )
    df_trainstar = df_all.iloc[train_idx].reset_index(drop=True)
    df_test = df_all.iloc[test_idx].reset_index(drop=True)
    logger.info(f"Train*: {len(df_trainstar)} rows | Test: {len(df_test)} rows")

    # ------------------------------------------------------------------
    # Feature engineering
    # ------------------------------------------------------------------
    features = infer_feature_columns(df_all)
    logger.info(f"Inferred {len(features)} feature columns")

    X_trainstar = df_trainstar[features].fillna(0.0).values.astype(np.float32)
    X_test = df_test[features].fillna(0.0).values.astype(np.float32)

    mean = X_trainstar.mean(axis=0)
    std = X_trainstar.std(axis=0)
    X_trainstar_std = standardize_features(X_trainstar, mean, std)
    X_test_std = standardize_features(X_test, mean, std)

    # ------------------------------------------------------------------
    # Load ensemble models
    # ------------------------------------------------------------------
    config_path = merged_folder / "hp_search" / "best_config.json"
    with open(config_path) as f:
        best_cfg = json.load(f)
    logger.info(f"Best config: {best_cfg}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Device: {device}")

    models = load_ensemble_models(
        merged_folder=merged_folder,
        input_dim=len(features),
        hidden_dims=best_cfg["hidden_dims"],
        num_classes=3,
        dropout=0.0,
        activation=best_cfg["activation"],
        device=device,
    )
    logger.info(f"Loaded {len(models)} ensemble models")

    # ------------------------------------------------------------------
    # EDL inference (train* for percentile thresholds; test for ablation)
    # ------------------------------------------------------------------
    logger.info("--- Running ensemble inference on Train* + Test ---")
    edl_trainstar = ensemble_predict(models, X_trainstar_std, device)
    edl_test = ensemble_predict(models, X_test_std, device)
    logger.info(
        f"Train* vacuity: mean={edl_trainstar['vacuity'].mean():.4f}, "
        f"std={edl_trainstar['vacuity'].std():.4f}"
    )
    logger.info(
        f"Test vacuity:   mean={edl_test['vacuity'].mean():.4f}, "
        f"std={edl_test['vacuity'].std():.4f}"
    )

    # ------------------------------------------------------------------
    # Percentile thresholds (from train* vacuity — same as Phase B.4.D)
    # ------------------------------------------------------------------
    percentile_cfg = compute_percentile_thresholds(edl_trainstar["vacuity"])
    p33 = percentile_cfg.recommend_as_is_max_vacuity
    p66 = percentile_cfg.reduce_size_max_vacuity
    fh = percentile_cfg.force_hold_min_vacuity
    logger.info(
        f"Percentile thresholds: p33={p33:.4f}, p66={p66:.4f}, force_hold={fh:.4f}"
    )

    # ------------------------------------------------------------------
    # W&B init
    # ------------------------------------------------------------------
    wandb_cfg = load_wandb_env()
    use_wandb = wandb_cfg["enabled"] and not args.no_wandb
    wandb_run = None
    if use_wandb:
        try:
            import wandb

            wandb_run = wandb.init(
                project=wandb_cfg["project"],
                entity=wandb_cfg["entity"],
                name=run_name,
                dir=str(run_dir),
                config={
                    "phase": "B.5",
                    "n_trainstar": len(df_trainstar),
                    "n_test": len(df_test),
                    "n_features": len(features),
                    "percentile_p33": p33,
                    "percentile_p66": p66,
                    "percentile_force_hold": fh,
                    "best_config": best_cfg,
                    "split_seed": split_seed,
                },
            )
            logger.info(
                f"W&B: project={wandb_cfg['project']}, entity={wandb_cfg['entity']}"
            )
        except Exception as e:
            logger.warning(f"W&B init failed: {e}")
            use_wandb = False

    # ------------------------------------------------------------------
    # Ablation A1: IQN-only
    # ------------------------------------------------------------------
    logger.info("=" * 60)
    logger.info("ABLATION A1: IQN-only")
    df_a1 = build_ablation_a1(df_test)
    metrics_a1 = compute_ablation_metrics(
        df_a1["final_action"],
        df_test["edl_a_cf_label"],
        source_actions=None,
    )
    df_a1.to_csv(run_dir / "audit" / "ablation_a1_iqn_only.csv", index=False)
    logger.info(
        f"A1 IQN-only: acc={metrics_a1['overall_acc']:.4f}, "
        f"macro_f1={metrics_a1['macro_f1']:.4f}, "
        f"n_modified={metrics_a1['n_modified']}"
    )

    # ------------------------------------------------------------------
    # Ablation A2: IQN + HDP
    # ------------------------------------------------------------------
    logger.info("=" * 60)
    logger.info("ABLATION A2: IQN + HDP")
    df_a2 = build_ablation_a2(df_test)
    metrics_a2 = compute_ablation_metrics(
        df_a2["final_action"],
        df_test["edl_a_cf_label"],
        source_actions=df_a2["source_action"],
    )
    df_a2.to_csv(run_dir / "audit" / "ablation_a2_iqn_hdp.csv", index=False)
    logger.info(
        f"A2 IQN+HDP: acc={metrics_a2['overall_acc']:.4f}, "
        f"macro_f1={metrics_a2['macro_f1']:.4f}, "
        f"n_modified={metrics_a2['n_modified']} (vs A1)"
    )

    # ------------------------------------------------------------------
    # Ablation A3: IQN + EDL (no HDP)
    # ------------------------------------------------------------------
    logger.info("=" * 60)
    logger.info("ABLATION A3: IQN + EDL (HDP bypassed)")
    df_a3 = build_ablation_a3(df_test, edl_test, percentile_cfg)
    a3_final = df_a3["final_action_after_edl_gate"]
    metrics_a3 = compute_ablation_metrics(
        a3_final,
        df_test["edl_a_cf_label"],
        source_actions=df_a3["source_action"],
    )
    df_a3.to_csv(run_dir / "audit" / "ablation_a3_iqn_edl.csv", index=False)
    logger.info(
        f"A3 IQN+EDL: acc={metrics_a3['overall_acc']:.4f}, "
        f"macro_f1={metrics_a3['macro_f1']:.4f}, "
        f"n_modified={metrics_a3['n_modified']} (vs A1)"
    )

    # ------------------------------------------------------------------
    # Ablation A4: IQN + HDP + EDL (full pipeline)
    # ------------------------------------------------------------------
    logger.info("=" * 60)
    logger.info("ABLATION A4: IQN + HDP + EDL (full pipeline)")
    df_a4 = build_ablation_a4(df_test, edl_test, percentile_cfg)
    a4_final = df_a4["final_action_after_edl_gate"]
    metrics_a4 = compute_ablation_metrics(
        a4_final,
        df_test["edl_a_cf_label"],
        source_actions=df_a4["source_action"],
    )
    df_a4.to_csv(run_dir / "audit" / "ablation_a4_iqn_hdp_edl.csv", index=False)
    logger.info(
        f"A4 IQN+HDP+EDL: acc={metrics_a4['overall_acc']:.4f}, "
        f"macro_f1={metrics_a4['macro_f1']:.4f}, "
        f"n_modified={metrics_a4['n_modified']} (vs A2)"
    )

    # ------------------------------------------------------------------
    # Collect all metrics
    # ------------------------------------------------------------------
    metrics_per_ablation = {
        "A1": metrics_a1,
        "A2": metrics_a2,
        "A3": metrics_a3,
        "A4": metrics_a4,
    }

    # ------------------------------------------------------------------
    # Compute component contributions (deltas)
    # ------------------------------------------------------------------
    delta_hdp_acc = metrics_a2["overall_acc"] - metrics_a1["overall_acc"]
    delta_hdp_f1 = metrics_a2["macro_f1"] - metrics_a1["macro_f1"]

    delta_edl_iqn_acc = metrics_a3["overall_acc"] - metrics_a1["overall_acc"]
    delta_edl_iqn_f1 = metrics_a3["macro_f1"] - metrics_a1["macro_f1"]

    delta_edl_hdp_acc = metrics_a4["overall_acc"] - metrics_a2["overall_acc"]
    delta_edl_hdp_f1 = metrics_a4["macro_f1"] - metrics_a2["macro_f1"]

    delta_combined_acc = metrics_a4["overall_acc"] - metrics_a1["overall_acc"]
    delta_combined_f1 = metrics_a4["macro_f1"] - metrics_a1["macro_f1"]

    contributions = {
        "hdp_contribution": {
            "formula": "A2 - A1",
            "delta_acc": delta_hdp_acc,
            "delta_macro_f1": delta_hdp_f1,
        },
        "edl_contribution_on_iqn": {
            "formula": "A3 - A1",
            "delta_acc": delta_edl_iqn_acc,
            "delta_macro_f1": delta_edl_iqn_f1,
        },
        "edl_contribution_on_hdp": {
            "formula": "A4 - A2",
            "delta_acc": delta_edl_hdp_acc,
            "delta_macro_f1": delta_edl_hdp_f1,
        },
        "combined_hdp_plus_edl": {
            "formula": "A4 - A1",
            "delta_acc": delta_combined_acc,
            "delta_macro_f1": delta_combined_f1,
        },
    }

    logger.info("--- Component Contributions ---")
    logger.info(
        f"  HDP contribution        (A2-A1): Δacc={delta_hdp_acc:+.4f}, Δf1={delta_hdp_f1:+.4f}"
    )
    logger.info(
        f"  EDL on IQN              (A3-A1): Δacc={delta_edl_iqn_acc:+.4f}, Δf1={delta_edl_iqn_f1:+.4f}"
    )
    logger.info(
        f"  EDL on HDP              (A4-A2): Δacc={delta_edl_hdp_acc:+.4f}, Δf1={delta_edl_hdp_f1:+.4f}"
    )
    logger.info(
        f"  Combined HDP+EDL        (A4-A1): Δacc={delta_combined_acc:+.4f}, Δf1={delta_combined_f1:+.4f}"
    )

    # ------------------------------------------------------------------
    # Save metrics JSONs
    # ------------------------------------------------------------------
    with open(run_dir / "metrics" / "per_ablation_metrics.json", "w") as f:
        json.dump(metrics_per_ablation, f, indent=2)

    cms_dict = {
        k: metrics_per_ablation[k]["confusion_matrix"] for k in metrics_per_ablation
    }
    with open(run_dir / "metrics" / "confusion_matrices.json", "w") as f:
        json.dump(cms_dict, f, indent=2)

    cross_summary = {}
    for key in ["A1", "A2", "A3", "A4"]:
        m = metrics_per_ablation[key]
        cross_summary[key] = {
            "ablation_id": key,
            "ablation_name": ABLATION_LABELS[key],
            "overall_acc": m["overall_acc"],
            "macro_f1": m["macro_f1"],
            "buy_f1": m["per_class"].get("BUY", {}).get("f1-score", 0.0),
            "sell_f1": m["per_class"].get("SELL", {}).get("f1-score", 0.0),
            "hold_f1": m["per_class"].get("HOLD", {}).get("f1-score", 0.0),
            "n_buy": m["action_distribution"].get("BUY", 0),
            "n_sell": m["action_distribution"].get("SELL", 0),
            "n_hold": m["action_distribution"].get("HOLD", 0),
            "n_modified": m["n_modified"],
        }
    cross_summary["component_contributions"] = contributions

    with open(run_dir / "metrics" / "cross_ablation_summary.json", "w") as f:
        json.dump(cross_summary, f, indent=2)

    # Cross-ablation comparison CSV (4-row tabular)
    comparison_rows = [cross_summary[k] for k in ["A1", "A2", "A3", "A4"]]
    pd.DataFrame(comparison_rows).to_csv(
        run_dir / "audit" / "ablation_comparison.csv", index=False
    )
    logger.info("Saved metrics JSONs and audit CSVs")

    # ------------------------------------------------------------------
    # Save test_set_predictions.csv
    # ------------------------------------------------------------------
    df_preds = df_test[
        [
            "decision_id",
            "date",
            "iqn_chosen_action",
            "hierarchical_action_type",
            "edl_a_cf_label",
        ]
    ].copy()
    df_preds["final_action_a1"] = df_a1["final_action"].values
    df_preds["final_action_a2"] = df_a2["final_action"].values
    df_preds["final_action_a3"] = (
        df_a3["final_action_after_edl_gate"].apply(normalize_action).values
    )
    df_preds["final_action_a4"] = (
        df_a4["final_action_after_edl_gate"].apply(normalize_action).values
    )
    df_preds["vacuity"] = edl_test["vacuity"]
    df_preds["disagreement"] = edl_test["disagreement"]
    df_preds["is_correct_a1"] = df_a1["is_correct"].values
    df_preds["is_correct_a2"] = df_a2["is_correct"].values
    df_preds["is_correct_a3"] = df_a3["is_correct"].values
    df_preds["is_correct_a4"] = df_a4["is_correct"].values
    df_preds.to_csv(run_dir / "data" / "test_set_predictions.csv", index=False)
    logger.info("Saved test_set_predictions.csv")

    # ------------------------------------------------------------------
    # Plots
    # ------------------------------------------------------------------
    logger.info("--- Generating plots ---")

    plot_ablation_accuracy_comparison(
        metrics_per_ablation,
        run_dir / "plots" / "ablation_accuracy_comparison.png",
    )
    logger.info("  ablation_accuracy_comparison.png")

    plot_ablation_confusion_matrices(
        metrics_per_ablation,
        run_dir / "plots" / "ablation_confusion_matrices.png",
    )
    logger.info("  ablation_confusion_matrices.png")

    if not args.quick:
        plot_ablation_per_class_metrics(
            metrics_per_ablation,
            run_dir / "plots" / "ablation_per_class_metrics.png",
        )
        logger.info("  ablation_per_class_metrics.png")

        plot_ablation_action_distribution(
            metrics_per_ablation,
            df_test["edl_a_cf_label"],
            run_dir / "plots" / "ablation_action_distribution.png",
        )
        logger.info("  ablation_action_distribution.png")
    else:
        logger.info("  (per_class_metrics + action_distribution skipped in quick mode)")

    # ------------------------------------------------------------------
    # Summary markdown
    # ------------------------------------------------------------------
    logger.info("--- Generating summary ---")

    def _sign(v: float) -> str:
        return f"{v:+.4f}"

    summary_lines = [
        "# Phase B.5 Ablation Suite — Run Summary",
        "",
        f"**Run:** `{run_name}`",
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## Data",
        "",
        f"- Train\\* size: **{len(df_trainstar)}** rows (used for percentile thresholds only)",
        f"- Test size: **{len(df_test)}** rows",
        f"- Features: **{len(features)}** columns",
        f"- Ground truth: `edl_a_cf_label` (counterfactual hindsight labels)",
        "",
        "## Percentile Thresholds (A3 / A4)",
        "",
        f"Computed from train\\* vacuity distribution:",
        f"- `rec_as_is_max_vacuity` = **{p33:.4f}** (p33)",
        f"- `reduce_size_max_vacuity` = **{p66:.4f}** (p66)",
        f"- `force_hold_min_vacuity` = **{fh:.4f}** (max(p66, 0.50))",
        "",
        "## Ablation Results",
        "",
        "| Ablation | Overall Acc | Macro F1 | BUY F1 | SELL F1 | HOLD F1 | n\\_modified |",
        "|---|---|---|---|---|---|---|",
    ]

    for key in ["A1", "A2", "A3", "A4"]:
        m = metrics_per_ablation[key]
        buy_f1 = m["per_class"].get("BUY", {}).get("f1-score", 0.0)
        sell_f1 = m["per_class"].get("SELL", {}).get("f1-score", 0.0)
        hold_f1 = m["per_class"].get("HOLD", {}).get("f1-score", 0.0)
        row = (
            f"| {ABLATION_LABELS[key]} "
            f"| {m['overall_acc']:.4f} "
            f"| {m['macro_f1']:.4f} "
            f"| {buy_f1:.4f} "
            f"| {sell_f1:.4f} "
            f"| {hold_f1:.4f} "
            f"| {m['n_modified']} |"
        )
        summary_lines.append(row)

    summary_lines += [
        "",
        "## Component Contributions",
        "",
        (
            "This table quantifies the marginal contribution of each pipeline component. "
            "All deltas are computed against the IQN-only baseline (A1) or "
            "the next-upstream stage. Positive values indicate improvement over cf\\_label."
        ),
        "",
        "| Component | Formula | Δ Accuracy | Δ Macro F1 |",
        "|---|---|---|---|",
        f"| HDP contribution | A2 − A1 | {_sign(delta_hdp_acc)} | {_sign(delta_hdp_f1)} |",
        f"| EDL contribution on IQN | A3 − A1 | {_sign(delta_edl_iqn_acc)} | {_sign(delta_edl_iqn_f1)} |",
        f"| EDL contribution on HDP | A4 − A2 | {_sign(delta_edl_hdp_acc)} | {_sign(delta_edl_hdp_f1)} |",
        f"| Combined HDP+EDL | A4 − A1 | {_sign(delta_combined_acc)} | {_sign(delta_combined_f1)} |",
        "",
        "## Action Distribution",
        "",
        "| Ablation | BUY | SELL | HOLD |",
        "|---|---|---|---|",
    ]

    n_test = len(df_test)
    for key in ["A1", "A2", "A3", "A4"]:
        dist = metrics_per_ablation[key]["action_distribution"]
        row = (
            f"| {ABLATION_LABELS[key]} "
            f"| {dist.get('BUY', 0)} ({dist.get('BUY', 0)/n_test:.1%}) "
            f"| {dist.get('SELL', 0)} ({dist.get('SELL', 0)/n_test:.1%}) "
            f"| {dist.get('HOLD', 0)} ({dist.get('HOLD', 0)/n_test:.1%}) |"
        )
        summary_lines.append(row)

    truth_dist = df_test["edl_a_cf_label"].apply(normalize_action).value_counts()
    summary_lines.append(
        f"| Ground Truth "
        f"| {truth_dist.get('BUY', 0)} ({truth_dist.get('BUY', 0)/n_test:.1%}) "
        f"| {truth_dist.get('SELL', 0)} ({truth_dist.get('SELL', 0)/n_test:.1%}) "
        f"| {truth_dist.get('HOLD', 0)} ({truth_dist.get('HOLD', 0)/n_test:.1%}) |"
    )

    summary_lines += [
        "",
        "## Ensemble Uncertainty (Test Set)",
        "",
        f"- Mean vacuity: **{edl_test['vacuity'].mean():.4f}** "
        f"(std={edl_test['vacuity'].std():.4f})",
        f"- Mean disagreement: **{edl_test['disagreement'].mean():.4f}**",
        "",
        "---",
        f"*Run directory: `{run_dir}`*",
    ]

    summary_md = "\n".join(summary_lines)
    with open(run_dir / "summary" / "phase_b5_summary.md", "w") as f:
        f.write(summary_md)

    # Summary JSON
    summary_json = {
        "run_name": run_name,
        "n_trainstar": len(df_trainstar),
        "n_test": len(df_test),
        "n_features": len(features),
        "percentile_thresholds": {"p33": p33, "p66": p66, "force_hold": fh},
        "cross_ablation": {
            k: {
                "overall_acc": metrics_per_ablation[k]["overall_acc"],
                "macro_f1": metrics_per_ablation[k]["macro_f1"],
                "n_modified": metrics_per_ablation[k]["n_modified"],
            }
            for k in ["A1", "A2", "A3", "A4"]
        },
        "component_contributions": contributions,
        "test_vacuity_mean": float(edl_test["vacuity"].mean()),
        "test_vacuity_std": float(edl_test["vacuity"].std()),
    }
    with open(run_dir / "summary" / "phase_b5_summary.json", "w") as f:
        json.dump(summary_json, f, indent=2)

    # ------------------------------------------------------------------
    # Config JSON
    # ------------------------------------------------------------------
    phase_b5_config = {
        "combined_csv": str(combined_csv),
        "merged_folder": str(merged_folder),
        "split_seed": split_seed,
        "test_split_ratio": test_split_ratio,
        "n_trainstar": len(df_trainstar),
        "n_test": len(df_test),
        "n_features": len(features),
        "features": features,
        "best_config": best_cfg,
        "percentile_thresholds": {"p33": p33, "p66": p66, "force_hold": fh},
        "quick_mode": args.quick,
        "wandb_enabled": use_wandb,
    }
    with open(run_dir / "config" / "phase_b5_config.json", "w") as f:
        json.dump(phase_b5_config, f, indent=2)

    # ------------------------------------------------------------------
    # W&B logging
    # ------------------------------------------------------------------
    if use_wandb:
        try:
            for key in ["A1", "A2", "A3", "A4"]:
                m = metrics_per_ablation[key]
                prefix = f"ablation/{key.lower()}"
                wandb.log(
                    {
                        f"{prefix}/overall_acc": m["overall_acc"],
                        f"{prefix}/macro_f1": m["macro_f1"],
                        f"{prefix}/buy_f1": m["per_class"]
                        .get("BUY", {})
                        .get("f1-score", 0.0),
                        f"{prefix}/sell_f1": m["per_class"]
                        .get("SELL", {})
                        .get("f1-score", 0.0),
                        f"{prefix}/hold_f1": m["per_class"]
                        .get("HOLD", {})
                        .get("f1-score", 0.0),
                        f"{prefix}/n_modified": m["n_modified"],
                    }
                )

            wandb.log(
                {
                    "contributions/hdp_delta_acc": delta_hdp_acc,
                    "contributions/hdp_delta_f1": delta_hdp_f1,
                    "contributions/edl_on_iqn_delta_acc": delta_edl_iqn_acc,
                    "contributions/edl_on_iqn_delta_f1": delta_edl_iqn_f1,
                    "contributions/edl_on_hdp_delta_acc": delta_edl_hdp_acc,
                    "contributions/edl_on_hdp_delta_f1": delta_edl_hdp_f1,
                    "contributions/combined_delta_acc": delta_combined_acc,
                    "contributions/combined_delta_f1": delta_combined_f1,
                }
            )

            comparison_table = wandb.Table(
                columns=[
                    "ablation_id",
                    "ablation_name",
                    "overall_acc",
                    "macro_f1",
                    "buy_f1",
                    "sell_f1",
                    "hold_f1",
                    "n_modified",
                ]
            )
            for key in ["A1", "A2", "A3", "A4"]:
                m = metrics_per_ablation[key]
                comparison_table.add_data(
                    key,
                    ABLATION_LABELS[key],
                    m["overall_acc"],
                    m["macro_f1"],
                    m["per_class"].get("BUY", {}).get("f1-score", 0.0),
                    m["per_class"].get("SELL", {}).get("f1-score", 0.0),
                    m["per_class"].get("HOLD", {}).get("f1-score", 0.0),
                    m["n_modified"],
                )
            wandb.log({"cross_ablation_comparison": comparison_table})

            wandb_run.finish()
            logger.info("W&B logging complete")
        except Exception as e:
            logger.warning(f"W&B logging error: {e}")

    # ------------------------------------------------------------------
    # Final summary
    # ------------------------------------------------------------------
    logger.info("=" * 80)
    logger.info("=== Phase B.5 Complete ===")
    logger.info(f"Run dir: {run_dir}")
    logger.info("Ablation results:")
    for key in ["A1", "A2", "A3", "A4"]:
        m = metrics_per_ablation[key]
        logger.info(
            f"  {ABLATION_LABELS[key]:20s}  "
            f"acc={m['overall_acc']:.4f}  f1={m['macro_f1']:.4f}  "
            f"n_modified={m['n_modified']}"
        )
    logger.info("Component contributions:")
    logger.info(
        f"  HDP        (A2-A1): Δacc={delta_hdp_acc:+.4f}, Δf1={delta_hdp_f1:+.4f}"
    )
    logger.info(
        f"  EDL/IQN    (A3-A1): Δacc={delta_edl_iqn_acc:+.4f}, Δf1={delta_edl_iqn_f1:+.4f}"
    )
    logger.info(
        f"  EDL/HDP    (A4-A2): Δacc={delta_edl_hdp_acc:+.4f}, Δf1={delta_edl_hdp_f1:+.4f}"
    )
    logger.info(
        f"  HDP+EDL    (A4-A1): Δacc={delta_combined_acc:+.4f}, Δf1={delta_combined_f1:+.4f}"
    )
    logger.info("=" * 80)

    return 0


if __name__ == "__main__":
    sys.exit(main())
